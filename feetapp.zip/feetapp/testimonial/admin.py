from django.contrib import admin

# Register your models here.

from testimonial.models import Testimonial

admin.site.register(Testimonial)
