from django.shortcuts import get_object_or_404
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Worker
from .serializers import WorkerSerializer

@api_view(['GET'])
def home_page(request):
    return Response({'message': 'Welcome to Workers API!'})

@api_view(['GET'])
def get_Workers(request):
    Workers = Worker.objects.all()
    serializer = WorkerSerializer(Workers, many=True)
    return Response(serializer.data)

@api_view(['POST'])
def add_Worker(request):
    serializer = WorkerSerializer(data=request.data)
    if serializer.is_valid():
     serializer.save()
    return Response(
             {'message':'Worker added','data': serializer.data},
            status=status.HTTP_201_CREATED,
            )
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
@api_view(['GET'])
def get_Worker(request, id):
    Worker = get_object_or_404(Worker, id=id)
    serializer = WorkerSerializer(Worker)
    return Response(serializer.data)