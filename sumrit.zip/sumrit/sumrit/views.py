from  django.http import HttpResponse
from  django.shortcuts import render
from django.template.loader import render_to_string
from django.core.mail import EmailMultiAlternatives
from contactdetails.models import Contact
from contactdetails.forms import ContactForm
from testimonial.models import Testimonial
import requests

def blog(request):
    return render(request, 'blog.html')


def HomePage(request):
#    if request.method == 'POST':
#         name = request.POST.get('username')
#         email = request.POST.get('useremail')
#         subject = request.POST.get('usersubject')
#         message = request.POST.get('usertext')

#         # Save contact to database
#         allData = Contact(
#             name=name,
#             email=email,
#             subject=subject,
#             message=message
#         )
#         allData.save()

#         # Create HTML email content
#         html_content = render_to_string('email_template.html', {
#             'name': name,
#             'email': email,
#             'subject': subject,
#             'message': message,
#         })

#         # Plain text fallback
#         text_content = (
#             f"Dear {name},\n\n"
#             "Thank you for contacting Sangam University. "
#             "We have received your message and will get back to you soon.\n\n"
#             "Best regards,\nSangam University Support Team"
#         )

#         # Send confirmation email to user
#         user_email = EmailMultiAlternatives(
#             subject=subject,
#             body=text_content,
#             from_email="hackerorwhat160@gmail.com",
#             to=[email],
#         )
#         user_email.attach_alternative(html_content, "text/html")
#         user_email.send(fail_silently=False)

#         # Send notification to admin
#         admin_subject = f"New Contact Form Submission from {name}"
#         admin_message = (
#             f"Name: {name}\n"
#             f"Email: {email}\n"
#             f"Subject: {subject}\n"
#             f"Message:\n{message}\n"
#         )

#         admin_email = EmailMultiAlternatives(
#             subject=admin_subject,
#             body=admin_message,
#             from_email="hackerorwhat160@gmail.com",
#             to=["hackerorwhat160@gmail.com"],
#         )
#         admin_email.send(fail_silently=False)



#         return render(request, 'index.html', {'name': name})

   return render(request, "index.html")

def contact_view(request):
    if request.method == 'POST':
        name = request.POST.get('username')
        email = request.POST.get('useremail')
        subject = request.POST.get('usersubject')
        message = request.POST.get('usermessage')

        # Save contact to database
        allData = Contact(
            name=name,
            email=email,
            subject=subject,
            message=message
        )
        allData.save()

        # Create HTML email content
        html_content = render_to_string('email_template.html', {
            'name': name,
            'email': email,
            'subject': subject,
            'message': message,
        })

        # Plain text fallback
        text_content = (
            f"Dear {name},\n\n"
            "Thank you for contacting Sangam University. "
            "We have received your message and will get back to you soon.\n\n"
            "Best regards,\nSangam University Support Team"
        )

        # Send confirmation email to user
        user_email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email="anshuchouhan058@gmail.com",
            to=[email],
        )
        user_email.attach_alternative(html_content, "text/html")
        user_email.send(fail_silently=False)

        # Send notification to admin
        admin_subject = f"New Contact Form Submission from {name}"
        admin_message = (
            f"Name: {name}\n"
            f"Email: {email}\n"
            f"Subject: {subject}\n"
            f"Message:\n{message}\n"
        )

        admin_email = EmailMultiAlternatives(
            subject=admin_subject,
            body=admin_message,
            from_email="hackerorwhat160@gmail.com",
            to=["hackerorwhat160@gmail.com"],
        )
        admin_email.send(fail_silently=False)



        return render(request, 'index.html', {'name': name})

    
    return render(request, 'index.html')


# testimonial
def HomePage(request):
    testimonials = Testimonial.objects.all()
    print(testimonials)   # Debug in console
    return render(request, 'index.html', {'testimonials': testimonials})


#api
from django.shortcuts import render

API_URL = "https://api.api-ninjas.com/v1/exercises"
API_KEY = "/EtnqSGKCM3olIWiksWaGg==6F8mIWZ7908AKX9p"   # put your key here or load from environment

def exercise_search(request):
    return render(request, "exercise_search.html")


def exercise_results(request):
    # collect user search parameters
    name = request.GET.get("name", "")
    muscle = request.GET.get("muscle", "")
    ex_type = request.GET.get("type", "")
    difficulty = request.GET.get("difficulty", "")

    params = {}

    if name:
        params["name"] = name
    if muscle:
        params["muscle"] = muscle
    if ex_type:
        params["type"] = ex_type
    if difficulty:
        params["difficulty"] = difficulty

    # API request
    response = requests.get(
        API_URL,
        headers={"X-Api-Key": API_KEY},
        params=params,
    )

    if response.status_code == 200:
        exercises = response.json()
    else:
        exercises = []
    
    return render(request, "exercise_results.html", {
        "exercises": exercises,
        "params": params
   
    })
    
