from django.db import models

class About(models.Model):
    title = models.CharField(max_length=200, default="#1 App For Your Fitness")
    description = models.TextField(default="Write your about description here.")
    image = models.ImageField(upload_to='about/', blank=True, null=True)
    installs = models.PositiveIntegerField(default=1234)         # optional
    reviews = models.PositiveIntegerField(default=1234)          # optional

    def __str__(self):
        return self.title
